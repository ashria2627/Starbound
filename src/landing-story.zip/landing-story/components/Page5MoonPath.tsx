import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { OrbitCharacter } from './OrbitCharacter';
import { MissionIllustration } from './MissionIllustration';
import { LunaIllustration } from './LunaIllustration';
import { ApolloIllustration } from './ApolloIllustration';
import { InterviewChat } from './InterviewChat';
import { SpaceGlossaryWord } from './SpaceGlossaryWord';
import { playSceneMusic, playPageTurn, playRoverRoll, playRadioBeep } from '../utils/sound';
import { speakDialogue, getSpeechEnabled, getAutoSpeakEnabled } from '../utils/speech';

interface Page5Props {
  onSwitchDestination?: (dest: 'mars' | 'deep_space') => void;
  autoSpeak?: boolean;
}

export const Page5MoonPath: React.FC<Page5Props> = ({ autoSpeak = true }) => {
  const [activeBeat, setActiveBeat] = useState(0);
  const scrollTimeoutRef = useRef<number | null>(null);

  const beats = useMemo(() => [
    {
      pageNumber: 12,
      layout: 'right', // Orbit on right, writing on left
      speaker: 'orbit' as const,
      speakerName: 'Orbit',
      isConversation: false,
      leadQuote: "Hello! This is the Moon!",
      bodyComponent: (
        <span>
          The Moon has no wind or rain. Its dusty ground is called <SpaceGlossaryWord termKey="regolith" displayText="lunar regolith" />. Footprints last millions of years!
        </span>
      ),
      speechText: "Hello! This is the Moon! No wind. No rain. Footprints stay for millions of years!",
      scienceFact: "The Moon's gravity is 1/6 of Earth's. You could jump about six times higher!",
    },
    {
      id: 'moon-p4',
      pageNumber: 13,
      layout: 'both_luna', // BOTH Orbit and Luna 1 together!
      speaker: 'luna1' as const,
      speakerName: 'Luna 1 & Orbit',
      isConversation: true,
      leadQuote: "Beep! I missed the Moon!",
      bodyComponent: (
        <span>
          I was aiming for the Moon. I flew past it! But I felt the <SpaceGlossaryWord termKey="solar_wind" displayText="solar wind" />. Nobody had done that before!
        </span>
      ),
      speechText: "Beep beep! I missed the Moon! But I found the solar wind!",
      scienceFact: "Luna 1 flew in January 1959. It was the first to escape Earth's pull and the first to circle the Sun.",
      interview: [["Orbit", "Luna 1, were you the first to reach the Moon's neighborhood?"], ["Luna 1", "Yep! I launched in 1959 and became the first spacecraft to reach the Moon's {{vicinity|vicinity}}!"], ["Orbit", "Did you actually land there?"], ["Luna 1", "Nope! I missed the Moon and ended up orbiting the Sun instead."], ["Orbit", "Oops! So was your mission a failure?"], ["Luna 1", "Not at all! I detected the {{solar_wind|solar wind}} and made important space measurements."], ["Orbit", "And now?"], ["Luna 1", "I'm still silently orbiting the Sun!"]] as [string, string][],
    },
    {
      pageNumber: 14,
      layout: 'both_generic',
      speaker: 'luna10' as const,
      speakerName: 'Luna 10 & Orbit',
      isConversation: true,
      leadQuote: "Hi! I'm Luna 10!",
      bodyComponent: (
        <span>
          Luna 10 was the first to <SpaceGlossaryWord termKey="orbit" displayText="orbit" /> the Moon. It studied the Moon for about two months.
        </span>
      ),
      speechText: "Hi! I'm Luna 10! I was the first to orbit the Moon!",
      scienceFact: "Luna 10 reached Moon orbit on 3 April 1966. It was the first spacecraft to orbit another world!",
      interview: [["Orbit", "Luna 10, were you the first to orbit the Moon?"], ["Luna 10", "Yep! I became the first spacecraft to orbit another world."], ["Orbit", "What were you looking for?"], ["Luna 10", "I studied the Moon's gravity, magnetic field, radiation, and environment."], ["Orbit", "Did you keep working forever?"], ["Luna 10", "Nope! My mission ended after about two months."], ["Orbit", "So where are you now?"], ["Luna 10", "Quiet now. On a long vacation!"]] as [string, string][],
      art: {"emoji": "🛰️", "name": "Luna 10", "year": "1966"},
      orbitLine: "Luna 10, how did you circle the Moon?",
    },
    {
      id: 'moon-p5',
      pageNumber: 14,
      layout: 'both_apollo', // BOTH Orbit and Apollo Rover together!
      speaker: 'apollo' as const,
      speakerName: 'Apollo 15 Rover & Orbit',
      isConversation: true,
      leadQuote: "Vroom! I'm the Moon buggy!",
      bodyComponent: (
        <span>
          My wheels were made of wire. They didn't sink in the <SpaceGlossaryWord termKey="regolith" displayText="regolith" />. Astronauts drove me about 28 kilometers on Apollo 15!
        </span>
      ),
      speechText: "Vroom! I'm the Moon buggy! Astronauts drove me far!",
      scienceFact: "On Apollo 17, astronauts found orange volcanic glass. It formed 3.6 billion years ago!",
      interview: [["Orbit", "Buggy, how did you travel?"], ["Apollo Rover", "Inside a rocket! Folded up!"], ["Orbit", "How fast were you?"], ["Apollo Rover", "Slow. About 13 kilometers an hour."], ["Orbit", "What did you help find?"], ["Apollo Rover", "Old Moon rocks! Yay!"]] as [string, string][],
    },
    {
      id: 'moon-p6',
      pageNumber: 15,
      layout: 'center',
      speaker: 'orbit' as const,
      speakerName: 'Orbit',
      isConversation: false,
      leadQuote: "Goodbye is hard. Thank you, rovers.",
      bodyComponent: (
        <span>
          Astronauts parked the rovers and flew home. Three Apollo rovers still rest on the Moon.
        </span>
      ),
      speechText: "Goodbye is hard. Thank you, rovers. Three still rest on the Moon.",
      scienceFact: "Apollo 15's rover camera let people on Earth watch the rocket lift off from the Moon in 1971.",
      interview: [["Orbit", "Rover, are you lonely?"], ["Apollo Rover", "A little. But happy."], ["Orbit", "Why happy?"], ["Apollo Rover", "I helped people learn!"]] as [string, string][],
    },
    {
      pageNumber: 16,
      layout: 'left', // Orbit on left, hope beat
      speaker: 'orbit' as const,
      speakerName: 'Orbit',
      isConversation: false,
      leadQuote: "New explorers are coming back!",
      bodyComponent: (
        <span>
          NASA's Artemis program is going back. New astronauts will visit the Moon. Maybe you will go one day!
        </span>
      ),
      speechText: "New explorers are coming back! Maybe you will visit too!",
      scienceFact: "NASA's Artemis will explore the Moon's south pole. Ice hides in its dark craters!",
    },
  ], []);

  // FIX: Auto-voice on arrival when moving to this story
  useEffect(() => {
    playSceneMusic('moon');

    const arrivalVoiceTimer = window.setTimeout(() => {
      if (autoSpeak && getAutoSpeakEnabled()) {
        speakDialogue(beats[0].speaker, beats[0].speechText, { skipSoundCue: true });
      }
    }, 300);

    return () => window.clearTimeout(arrivalVoiceTimer);
  }, [autoSpeak, beats]);

  const handleSpeak = useCallback((beatIdx: number) => {
    const beat = beats[beatIdx];
    speakDialogue(beat.speaker, beat.speechText, { manualTrigger: true });
  }, [beats]);

  // Debounced scroll observer
  useEffect(() => {
    const handleScroll = () => {
      const beatElements = document.querySelectorAll('.moon-beat');
      if (beatElements.length === 0) return;

      const vCenter = window.innerHeight * 0.45;
      let closestIdx = 0;
      let minDistance = Infinity;

      beatElements.forEach((el, idx) => {
        const rect = el.getBoundingClientRect();
        const dist = Math.abs(rect.top + rect.height / 2 - vCenter);
        if (dist < minDistance) {
          minDistance = dist;
          closestIdx = idx;
        }
      });

      if (closestIdx !== activeBeat) {
        setActiveBeat(closestIdx);
        playPageTurn();
        const beat = beats[closestIdx];

        if (beat.speaker === 'luna1') {
          playRadioBeep(620, 0.12);
        } else if (beat.speaker === 'apollo') {
          playRoverRoll();
        }

        if (scrollTimeoutRef.current) window.clearTimeout(scrollTimeoutRef.current);
        scrollTimeoutRef.current = window.setTimeout(() => {
          if (autoSpeak && getAutoSpeakEnabled()) {
            speakDialogue(beat.speaker, beat.speechText, { skipSoundCue: true });
          }
        }, 220);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => {
      window.removeEventListener('scroll', handleScroll);
      if (scrollTimeoutRef.current) window.clearTimeout(scrollTimeoutRef.current);
    };
  }, [activeBeat, beats, autoSpeak]);

  return (
    <section
      id="chosen-destination-story"
      className="relative w-full py-16 sm:py-24 text-amber-900 overflow-hidden bg-gradient-to-b from-[#fff1dc] via-[#ffe0b8] to-[#fff1dc]"
    >
      <div className="absolute inset-0 pointer-events-none opacity-40 z-0">
        <svg viewBox="0 0 1400 900" className="w-full h-full" preserveAspectRatio="none">
          <circle cx="1080" cy="180" r="45" fill="#38bdf8" />
          <circle cx="1075" cy="175" r="43" fill="#0284c7" />
          <path d="M 1060 160 Q 1090 150 1100 180 Q 1070 200 1060 160 Z" fill="#ffffff" opacity="0.8" />
          <circle cx="1080" cy="180" r="48" stroke="#38bdf8" strokeWidth="2" fill="none" opacity="0.5" />

          <polygon points="100,620 380,490 680,620" fill="#334155" opacity="0.4" />
          <polygon points="550,620 850,460 1150,620" fill="#1e293b" opacity="0.5" />
          <polygon points="980,620 1200,510 1380,620" fill="#334155" opacity="0.4" />

          <path d="M 0 660 Q 400 610 850 670 T 1400 640 L 1400 900 L 0 900 Z" fill="#0f172a" opacity="0.8" />
          <ellipse cx="320" cy="740" rx="90" ry="24" fill="#020617" opacity="0.6" stroke="#475569" strokeWidth="1.5" />
          <ellipse cx="850" cy="790" rx="140" ry="32" fill="#020617" opacity="0.7" stroke="#475569" strokeWidth="2" />
        </svg>
      </div>

      <div className="relative z-10 w-full flex flex-col items-center">
       
        <div className="pt-4 pb-12 px-4 text-center max-w-4xl mx-auto">
          
          <h2 className="text-3xl sm:text-5xl lg:text-6xl font-black text-amber-950 mt-3 tracking-tight drop-shadow-md">
            The Moon: Luna 1 & Apollo Buggy
          </h2>
          
        </div>

       
        <div className="w-full flex flex-col items-center space-y-16 sm:space-y-24">
          {beats.map((beat, idx) => {
            const isActive = activeBeat === idx;
            const isCenter = beat.layout === 'center';
            const isBothLuna = beat.layout === 'both_luna';
            const isBothApollo = beat.layout === 'both_apollo';
            const isBothGeneric = beat.layout === 'both_generic';
            const isRight = beat.layout === 'right';

            return (
              <div
                key={idx}
                id={beat.id}
                className={`moon-beat w-full min-h-[75vh] max-w-6xl px-4 sm:px-8 lg:px-12 flex items-center justify-center transition-all duration-500 ${
                  isActive ? 'opacity-100 scale-100' : 'opacity-65 scale-[0.98]'
                }`}
              >
               
                {isBothGeneric ? (
                  <div className="w-full flex flex-col items-center gap-6">
                    <div className="text-center max-w-3xl px-2">
                      <div className="text-lg sm:text-2xl text-amber-900/95 leading-relaxed font-bold">
                        {beat.bodyComponent}
                      </div>
                    </div>
                    <div className="w-full flex flex-row items-center justify-around gap-4 sm:gap-12 py-4">
                      <div className="flex flex-col items-center opacity-85 hover:opacity-100 transition-opacity">
                        <OrbitCharacter
                          mood="curious"
                          size="md"
                          onClick={() => speakDialogue('orbit', "Luna, you didn't quite hit the Moon, did you?")}
                        />
                        
                      </div>
                      <div className="text-amber-800 font-mono text-xs sm:text-sm opacity-75 animate-pulse">
                        <span>{beat.art?.emoji} ~ ~ ~ 🛰️</span>
                      </div>
                      <div className="flex flex-col items-center scale-105 filter drop-shadow-[0_0_20px_rgba(203,213,225,0.5)]">
                        <MissionIllustration
                          emoji={beat.art?.emoji || '🛰️'}
                          name={beat.art?.name || ''}
                          year={beat.art?.year || ''}
                          dark={false}
                          isSpeaking={isActive}
                          speechBubble={beat.leadQuote}
                          onClick={() => handleSpeak(idx)}
                        />
                      </div>
                    </div>
                    {beat.interview && <InterviewChat lines={beat.interview} dark={false} />}
                    <div className="p-4 sm:p-5 rounded-2xl bg-white/70 backdrop-blur-md border border-slate-500/40 shadow-xl max-w-2xl text-center">
                      <p className="text-sm sm:text-base font-semibold text-amber-800 leading-snug">
                        🌕 <strong className="text-amber-950">NASA Discovery:</strong> {beat.scienceFact}
                      </p>
                    </div>
                  </div>
                ) : isBothLuna ? (
                  <div className="w-full flex flex-col items-center gap-6">
                    <div className="text-center max-w-3xl px-2">
                    
                      <div className="text-lg sm:text-2xl text-amber-900/95 leading-relaxed font-bold">
                        {beat.bodyComponent}
                      </div>
                    </div>

                    <div className="w-full flex flex-row items-center justify-around gap-4 sm:gap-12 py-4">
                      
                      <div className="flex flex-col items-center opacity-85 hover:opacity-100 transition-opacity">
                        <OrbitCharacter
                          mood="curious"
                          size="md"
                          onClick={() => speakDialogue('orbit', "Luna, you didn't quite hit the Moon, did you?")}
                        />
                        
                      </div>

                      <div className="text-amber-800 font-mono text-xs sm:text-sm opacity-75 animate-pulse">
                        <span>🌕 ~ ~ ~ 🛰️</span>
                      </div>

                      
                      <div className="flex flex-col items-center scale-105 filter drop-shadow-[0_0_20px_rgba(203,213,225,0.5)]">
                        <LunaIllustration
                          isSpeaking={isActive}
                          speechBubble={beat.leadQuote}
                          onClick={() => handleSpeak(idx)}
                        />
                       
                      </div>
                    </div>

                    {beat.interview && <InterviewChat lines={beat.interview} dark={false} />}

                    <div className="p-4 sm:p-5 rounded-2xl bg-white/70 backdrop-blur-md border border-slate-500/40 shadow-xl max-w-2xl text-center">
                      <p className="text-sm sm:text-base font-semibold text-amber-800 leading-snug">
                        🌕 <strong className="text-amber-950">NASA Discovery:</strong> {beat.scienceFact}
                      </p>
                    </div>
                  </div>
                ) : isBothApollo ? (
                 
                  <div className="w-full flex flex-col items-center gap-6">
                    <div className="text-center max-w-3xl px-2">
                    
                      <div className="text-lg sm:text-2xl text-amber-900/95 leading-relaxed font-bold">
                        {beat.bodyComponent}
                      </div>
                    </div>

                    <div className="w-full flex flex-row items-center justify-around gap-4 sm:gap-12 py-4">
                      
                      <div className="flex flex-col items-center opacity-85 hover:opacity-100 transition-opacity">
                        <OrbitCharacter
                          mood="excited"
                          size="md"
                          onClick={() => speakDialogue('orbit', "Apollo Rover, how did you drive across the powdery Moon?")}
                        />
                        
                      </div>

                      <div className="text-amber-800 font-mono text-xs sm:text-sm opacity-75 animate-pulse">
                        <span>🚙 ~ ~ ~ 🛰️</span>
                      </div>

                      <div className="flex flex-col items-center scale-105 filter drop-shadow-[0_0_20px_rgba(203,213,225,0.5)]">
                        <ApolloIllustration
                          isSpeaking={isActive}
                          speechBubble={beat.leadQuote}
                          onClick={() => handleSpeak(idx)}
                        />
                       
                      </div>
                    </div>

                    {beat.interview && <InterviewChat lines={beat.interview} dark={false} />}

                    <div className="p-4 sm:p-5 rounded-2xl bg-white/70 backdrop-blur-md border border-slate-500/40 shadow-xl max-w-2xl text-center">
                      <p className="text-sm sm:text-base font-semibold text-amber-800 leading-snug">
                        🌕 <strong className="text-amber-950">NASA Discovery:</strong> {beat.scienceFact}
                      </p>
                    </div>
                  </div>
                ) : isCenter ? (
                 
                  <div className="w-full max-w-3xl flex flex-col items-center text-center gap-6">
                    <OrbitCharacter
                      mood="happy"
                      size="lg"
                      isSpeaking={isActive}
                      speechBubble={beat.leadQuote}
                      onClick={() => handleSpeak(idx)}
                    />

                    <div>
                     

                      <div className="text-lg sm:text-2xl text-amber-900/95 leading-relaxed font-bold mb-4">
                        {beat.bodyComponent}
                      </div>

                      {beat.interview && <InterviewChat lines={beat.interview} dark={false} />}

                      <div className="p-4 sm:p-5 rounded-2xl bg-white/70 backdrop-blur-md border border-slate-500/40 shadow-xl text-left inline-block">
                        <p className="text-sm sm:text-base font-semibold text-amber-800 leading-snug">
                          🌕 <strong className="text-amber-950">Lunar Fact:</strong> {beat.scienceFact}
                        </p>
                      </div>
                    </div>
                  </div>
                ) : (
                  
                  <div
                    className={`w-full max-w-5xl flex gap-8 lg:gap-14 items-center ${
                      isRight ? 'flex-col lg:flex-row-reverse justify-between' : 'flex-col lg:flex-row justify-between'
                    }`}
                  >
                    <div className="w-full lg:w-5/12 flex flex-col items-center justify-center">
                      <OrbitCharacter
                        mood="happy"
                        size="lg"
                        isSpeaking={isActive}
                        speechBubble={beat.leadQuote}
                        onClick={() => handleSpeak(idx)}
                      />
                    </div>

                    <div className="w-full lg:w-7/12 flex flex-col justify-center max-w-xl">
                      <h3 className="text-2xl sm:text-4xl lg:text-5xl font-extrabold text-amber-950 tracking-tight drop-shadow-md mb-3 leading-snug">
                        {beat.leadQuote}
                      </h3>

                      <div className="text-lg sm:text-2xl text-amber-900/95 leading-relaxed font-medium mb-4">
                        {beat.bodyComponent}
                      </div>

                      {beat.interview && <InterviewChat lines={beat.interview} dark={false} />}

                      <div className="p-4 sm:p-5 rounded-2xl bg-white/70 backdrop-blur-md border border-slate-500/40 shadow-xl">
                        <p className="text-sm sm:text-base font-semibold text-amber-800 leading-snug">
                          🌕 <strong className="text-amber-950">NASA Discovery:</strong> {beat.scienceFact}
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default Page5MoonPath;