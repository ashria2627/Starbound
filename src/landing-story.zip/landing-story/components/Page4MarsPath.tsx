import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { OrbitCharacter } from './OrbitCharacter';
import { SojournerIllustration } from './SojournerIllustration';
import { RoverIllustration } from './RoverIllustration';
import { InterviewChat } from './InterviewChat';
import { SpaceGlossaryWord } from './SpaceGlossaryWord';
import { playSceneMusic, playPageTurn, playRoverRoll, playOppyCue } from '../utils/sound';
import { speakDialogue, getSpeechEnabled, getAutoSpeakEnabled } from '../utils/speech';

interface Page4Props {
  onSwitchDestination?: (dest: 'moon' | 'deep_space') => void;
  autoSpeak?: boolean;
}

export const Page4MarsPath: React.FC<Page4Props> = ({ autoSpeak = true }) => {
  const [activeBeat, setActiveBeat] = useState(0);
  const scrollTimeoutRef = useRef<number | null>(null);

  const beats = useMemo(() => [
    {
      pageNumber: 12,
      layout: 'right', // Orbit on right, writing on left
      speaker: 'orbit' as const,
      speakerName: 'Orbit',
      isConversation: false,
      orangeVariant: 'sunlight' as const,
      leadQuote: "Hello, explorer! This is Mars!",
      bodyComponent: (
        <span>
          Mars is the Red Planet. Its dust is rusty. It has a thin <SpaceGlossaryWord termKey="atmosphere" displayText="atmosphere" />. Long ago, it had water!
        </span>
      ),
      speechText: "Hello, explorer! This is Mars, the Red Planet! Long ago, it had water!",
      scienceFact: "Mars has two potato-shaped moons, Phobos and Deimos. Its volcano Olympus Mons is 2.5 times taller than Mount Everest!",
    },
    {
      id: 'mars-p4',
      pageNumber: 13,
      layout: 'both_sojourner', // BOTH Orbit and Sojourner together!
      speaker: 'sojourner' as const,
      speakerName: 'Sojourner & Orbit',
      isConversation: true,
      orangeVariant: 'boulder' as const,
      leadQuote: "Hi! I'm Sojourner! I'm tiny!",
      bodyComponent: (
        <span>
          I have six wheels. I use a <SpaceGlossaryWord termKey="spectrometer" displayText="spectrometer" /> to check rocks. I checked a rock named Barnacle Bill!
        </span>
      ),
      speechText: "Hi! I'm Sojourner! I'm tiny! I have six wheels!",
      scienceFact: "Sojourner was built to work 7 Mars days. She worked 83! She was the first rover on Mars.",
      interview: [["Orbit", "Sojourner, how big are you?"], ["Sojourner", "Like a microwave oven!"], ["Orbit", "How long did you work?"], ["Sojourner", "Eighty-three Mars days! Yay!"], ["Orbit", "Where are you now?"], ["Sojourner", "Still on Mars. Resting."]] as [string, string][],
    },
    {
      id: 'mars-p5',
      pageNumber: 14,
      layout: 'both_oppy', // BOTH Orbit and Opportunity together!
      speaker: 'oppy' as const,
      speakerName: 'Opportunity (Oppy) & Orbit',
      isConversation: true,
      orangeVariant: 'meridiani' as const,
      leadQuote: "Hello! I'm Oppy! I found blueberries!",
      bodyComponent: (
        <span>
          My twin Spirit and I landed in 2004. We planned 90 days. I worked over 14 years! I found <SpaceGlossaryWord termKey="hematite" displayText="hematite" /> blueberries. They grow in water!
        </span>
      ),
      speechText: "Hi! I'm Oppy! I found tiny blueberries! They grow in water!",
      scienceFact: "Oppy drove 45.16 km. That is farther than a marathon!",
      interview: [["Orbit", "Oppy, what did you find?"], ["Oppy", "Tiny round blueberries! Made in water."], ["Orbit", "So Mars had water?"], ["Oppy", "Yes! Long, long ago."], ["Orbit", "Who is your twin?"], ["Oppy", "Spirit! She found water clues too."], ["Orbit", "You're both heroes!"]] as [string, string][],
    },
    {
      id: 'mars-p6',
      pageNumber: 15,
      layout: 'center', // Centered emotional climax
      speaker: 'oppy' as const,
      speakerName: 'Opportunity (Oppy)',
      isConversation: false,
      orangeVariant: 'storm' as const,
      leadQuote: "It's getting dark. I'm sleepy.",
      bodyComponent: (
        <span>
          In June 2018, a giant dust storm covered Mars. Dust hid the Sun. Oppy's panels couldn't make power. She went quiet.
        </span>
      ),
      speechText: "It's getting dark. My battery is low. Don't be sad.",
      scienceFact: "Oppy last talked to Earth on 10 June 2018. NASA said goodbye in February 2019.",
      interview: [["Orbit", "Oppy, are you okay?"], ["Oppy", "I'm sleepy. Battery's low."], ["Orbit", "Are you sad?"], ["Oppy", "No! I had fun."], ["Orbit", "Thank you, Oppy."], ["Oppy", "Thank you, friend!"]] as [string, string][],
    },
    {
      pageNumber: 16,
      layout: 'left', // Orbit on left, writing on right
      speaker: 'orbit' as const,
      speakerName: 'Orbit',
      isConversation: false,
      orangeVariant: 'hope' as const,
      leadQuote: "Oppy inspired everyone! Look up!",
      bodyComponent: (
        <span>
          Now new rovers explore Mars. Curiosity and Perseverance follow Oppy. Maybe you will build one!
        </span>
      ),
      speechText: "Oppy inspired everyone! New rovers follow her. Maybe you will too!",
      scienceFact: "Perseverance is exploring Jezero Crater, looking for signs of ancient life. Helicopter Ingenuity flew 72 times!",
    },
  ], []);

  // FIX: Auto-voice on arrival when moving to this story
  useEffect(() => {
    playSceneMusic('mars');

    const arrivalVoiceTimer = window.setTimeout(() => {
      if (autoSpeak && getAutoSpeakEnabled()) {
        speakDialogue(beats[0].speaker, beats[0].speechText, { skipSoundCue: true });
      }
    }, 300);

    return () => window.clearTimeout(arrivalVoiceTimer);
  }, [autoSpeak, beats]);

  const handleSpeak = useCallback((beatIdx: number) => {
    const beat = beats[beatIdx];
    speakDialogue(beat.speaker, beat.speechText, { manualTrigger: true });
  }, [beats]);

  // Debounced scroll listener
  useEffect(() => {
    const handleScroll = () => {
      const beatElements = document.querySelectorAll('.mars-beat');
      if (beatElements.length === 0) return;

      const vCenter = window.innerHeight * 0.45;
      let closestIdx = 0;
      let minDistance = Infinity;

      beatElements.forEach((el, idx) => {
        const rect = el.getBoundingClientRect();
        const dist = Math.abs(rect.top + rect.height / 2 - vCenter);
        if (dist < minDistance) {
          minDistance = dist;
          closestIdx = idx;
        }
      });

      if (closestIdx !== activeBeat) {
        setActiveBeat(closestIdx);
        playPageTurn();
        const beat = beats[closestIdx];

        if (beat.orangeVariant === 'storm') {
          playSceneMusic('opportunity_climax');
        } else if (beat.orangeVariant === 'hope') {
          playSceneMusic('opportunity_hope');
        } else {
          playSceneMusic('mars');
        }

        if (beat.speaker === 'sojourner') {
          playRoverRoll();
        } else if (beat.speaker === 'oppy') {
          playOppyCue();
        }

        if (scrollTimeoutRef.current) window.clearTimeout(scrollTimeoutRef.current);
        scrollTimeoutRef.current = window.setTimeout(() => {
          if (autoSpeak && getAutoSpeakEnabled()) {
            speakDialogue(beat.speaker, beat.speechText, { skipSoundCue: true });
          }
        }, 220);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => {
      window.removeEventListener('scroll', handleScroll);
      if (scrollTimeoutRef.current) window.clearTimeout(scrollTimeoutRef.current);
    };
  }, [activeBeat, beats, autoSpeak]);

  const activeorange = beats[activeBeat]?.orangeVariant || 'sunlight';

  return (
    <section
      id="chosen-destination-story"
      className={`relative w-full py-16 sm:py-24 text-amber-900 overflow-hidden transition-colors duration-1000 ${
        activeorange === 'storm'
          ? 'bg-gradient-to-b from-[#ffedd5] via-[#fed7aa] to-[#fff1dc]'
          : activeorange === 'hope'
          ? 'bg-gradient-to-b from-[#fed7aa] via-[#ffedd5] to-[#fff1dc]'
          : 'bg-gradient-to-b from-[#fff1dc] via-[#fed7aa] to-[#fff1dc]'
      }`}
    >
      <div className="absolute inset-0 pointer-events-none opacity-45 z-0 transition-opacity duration-1000">
        <svg viewBox="0 0 1400 900" className="w-full h-full" preserveAspectRatio="none">
          <polygon
            points="150,620 420,480 750,620"
            fill={activeorange === 'storm' ? '#271007' : '#9a3412'}
            opacity="0.4"
          />
          <path
            d="M 0 680 Q 400 580 850 680 T 1400 640 L 1400 900 L 0 900 Z"
            fill={activeorange === 'storm' ? '#1f0d06' : '#c2410c'}
            opacity="0.3"
          />
          <path
            d="M 0 760 Q 500 700 1000 760 L 1400 720 L 1400 900 L 0 900 Z"
            fill={activeorange === 'storm' ? '#140804' : '#7c2d12'}
            opacity="0.5"
          />
          <circle cx="280" cy="340" r="1.5" fill="#fed7aa" opacity="0.6" />
          <circle cx="620" cy="220" r="2" fill="#fdba74" opacity="0.7" />
          <circle cx="940" cy="380" r="1.5" fill="#fed7aa" opacity="0.5" />
          <circle cx="1120" cy="180" r="2.5" fill="#f97316" opacity="0.6" />
        </svg>
      </div>

      <div className="relative z-10 w-full flex flex-col items-center">
        {/* Header with Larger Font */}
        <div className="pt-4 pb-12 px-4 text-center max-w-4xl mx-auto">
         
          <h2 className="text-3xl sm:text-5xl lg:text-6xl font-black text-amber-950 mt-3 tracking-tight drop-shadow-md">
            The Red Planet: Sojourner & Oppy
          </h2>
        
        </div>

         <div className="w-full flex flex-col items-center space-y-16 sm:space-y-24">
          {beats.map((beat, idx) => {
            const isActive = activeBeat === idx;
            const isCenter = beat.layout === 'center';
            const isBothSojourner = beat.layout === 'both_sojourner';
            const isBothOppy = beat.layout === 'both_oppy';
            const isRight = beat.layout === 'right';

            return (
              <div
                key={idx}
                id={beat.id}
                className={`mars-beat w-full min-h-[75vh] max-w-6xl px-4 sm:px-8 lg:px-12 flex items-center justify-center transition-all duration-500 ${
                  isActive ? 'opacity-100 scale-100' : 'opacity-65 scale-[0.98]'
                }`}
              >
                
                {isBothSojourner ? (
                  <div className="w-full flex flex-col items-center gap-6">
                    <div className="text-center max-w-3xl px-2">
                     
                      <div className="text-lg sm:text-2xl text-amber-900/95 leading-relaxed font-bold">
                        {beat.bodyComponent}
                      </div>
                    </div>

                    <div className="w-full flex flex-row items-center justify-around gap-4 sm:gap-12 py-4">
                      {/* Left: Orbit */}
                      <div className="flex flex-col items-center opacity-85 hover:opacity-100 transition-opacity">
                        <OrbitCharacter
                          mood="curious"
                          size="md"
                          onClick={() => speakDialogue('orbit', "Sojourner, show us how you climbed those Martian rocks!")}
                        />
                        
                      </div>

                      <div className="text-orange-800 font-mono text-xs sm:text-sm opacity-75 animate-pulse">
                        <span>🏎️ ~ ~ ~ 🛰️</span>
                      </div>

                      {/* Right: Sojourner Speaking */}
                      <div className="flex flex-col items-center scale-105 filter drop-shadow-[0_0_20px_rgba(249,115,22,0.5)]">
                        <SojournerIllustration
                          isSpeaking={isActive}
                          speechBubble={beat.leadQuote}
                          onClick={() => handleSpeak(idx)}
                        />
                       
                      </div>
                    </div>

                    {beat.interview && <InterviewChat lines={beat.interview} dark={false} />}

                    <div className="p-4 sm:p-5 rounded-2xl bg-white/70 backdrop-blur-md border border-orange-500/40 shadow-xl max-w-2xl text-center">
                      <p className="text-sm sm:text-base font-semibold text-amber-800 leading-snug">
                        🔴 <strong className="text-amber-950">NASA Discovery:</strong> {beat.scienceFact}
                      </p>
                    </div>
                  </div>
                ) : isBothOppy ? (
                  
                  <div className="w-full flex flex-col items-center gap-6">
                    <div className="text-center max-w-3xl px-2">
                     
                      <div className="text-lg sm:text-2xl text-amber-900/95 leading-relaxed font-bold">
                        {beat.bodyComponent}
                      </div>
                    </div>

                    <div className="w-full flex flex-row items-center justify-around gap-4 sm:gap-12 py-4">
                      
                      <div className="flex flex-col items-center opacity-85 hover:opacity-100 transition-opacity">
                        <OrbitCharacter
                          mood="excited"
                          size="md"
                          onClick={() => speakDialogue('orbit', "Oppy, tell us about the ancient water you found on Mars!")}
                        />
                       
                      </div>

                      <div className="text-orange-800 font-mono text-xs sm:text-sm opacity-75 animate-pulse">
                        <span>✨ ~ ~ ~ 🛰️</span>
                      </div>

                     
                      <div className="flex flex-col items-center scale-105 filter drop-shadow-[0_0_20px_rgba(249,115,22,0.5)]">
                        <RoverIllustration
                          name="Oppy"
                          variant="celebrating"
                          size="lg"
                          speechBubble={beat.leadQuote}
                          onClick={() => handleSpeak(idx)}
                        />
                        
                      </div>
                    </div>

                    {beat.interview && <InterviewChat lines={beat.interview} dark={false} />}

                    <div className="p-4 sm:p-5 rounded-2xl bg-white/70 backdrop-blur-md border border-orange-500/40 shadow-xl max-w-2xl text-center">
                      <p className="text-sm sm:text-base font-semibold text-amber-800 leading-snug">
                        🔴 <strong className="text-amber-950">NASA Discovery:</strong> {beat.scienceFact}
                      </p>
                    </div>
                  </div>
                ) : isCenter ? (
                  
                  <div className="w-full max-w-3xl flex flex-col items-center text-center gap-6">
                    <RoverIllustration
                      name="Oppy"
                      variant="resting"
                      size="lg"
                      speechBubble={beat.leadQuote}
                      onClick={() => handleSpeak(idx)}
                    />

                    <div>
                      

                      <div className="text-lg sm:text-2xl text-amber-900/95 leading-relaxed font-bold mb-4">
                        {beat.bodyComponent}
                      </div>

                      {beat.interview && <InterviewChat lines={beat.interview} dark={false} />}

                      <div className="p-4 sm:p-5 rounded-2xl bg-white/70 backdrop-blur-md border border-orange-500/40 shadow-xl text-left inline-block">
                        <p className="text-sm sm:text-base font-semibold text-amber-800 leading-snug">
                          🔴 <strong className="text-amber-950">Martian Record:</strong> {beat.scienceFact}
                        </p>
                      </div>
                    </div>
                  </div>
                ) : (
                  
                  <div
                    className={`w-full max-w-5xl flex gap-8 lg:gap-14 items-center ${
                      isRight ? 'flex-col lg:flex-row-reverse justify-between' : 'flex-col lg:flex-row justify-between'
                    }`}
                  >
                    <div className="w-full lg:w-5/12 flex flex-col items-center justify-center">
                      <OrbitCharacter
                        mood={beat.orangeVariant === 'hope' ? 'gentle' : 'curious'}
                        size="lg"
                        isSpeaking={isActive}
                        speechBubble={beat.leadQuote}
                        onClick={() => handleSpeak(idx)}
                      />
                     
                    </div>

                    <div className="w-full lg:w-7/12 flex flex-col justify-center max-w-xl">
                     

                      <div className="text-lg sm:text-2xl text-amber-900/95 leading-relaxed font-bold mb-4">
                        {beat.bodyComponent}
                      </div>

                      {beat.interview && <InterviewChat lines={beat.interview} dark={false} />}

                      <div className="p-4 sm:p-5 rounded-2xl bg-white/70 backdrop-blur-md border border-orange-500/40 shadow-xl">
                        <p className="text-sm sm:text-base font-semibold text-amber-800 leading-snug">
                          🔴 <strong className="text-amber-950">NASA Discovery:</strong> {beat.scienceFact}
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default Page4MarsPath;