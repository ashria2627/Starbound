import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { OrbitCharacter } from './OrbitCharacter';
import { MissionIllustration } from './MissionIllustration';
import { PioneerIllustration } from './PioneerIllustration';
import { VoyagerIllustration } from './VoyagerIllustration';
import { InterviewChat } from './InterviewChat';
import { SpaceGlossaryWord } from './SpaceGlossaryWord';
import { playSceneMusic, playPageTurn, playOrbitCue } from '../utils/sound';
import { speakDialogue, getSpeechEnabled } from '../utils/speech';

interface Page6Props {
  onSwitchDestination?: (dest: 'mars' | 'moon') => void;
}

export const Page6DeepSpacePath: React.FC<Page6Props> = () => {
  const [activeBeat, setActiveBeat] = useState(0);
  const scrollTimeoutRef = useRef<number | null>(null);

  const beats = useMemo(() => [
    {
      pageNumber: 12,
      layout: 'left', // Orbit on left, writing on right
      speaker: 'orbit' as const,
      speakerName: 'Orbit',
      isConversation: false,
      leadQuote: "Let's zoom past Mars!",
      bodyComponent: (
        <span>
          Past Mars is the <SpaceGlossaryWord termKey="asteroid_belt" displayText="asteroid belt" />. Then giant Jupiter and ringed Saturn. It is very far!
        </span>
      ),
      speechText: "Let's zoom past Mars! Giant planets are next!",
      scienceFact: "More than 1,300 Earths fit inside Jupiter. Its Red Spot is a storm wider than Earth!",
    },
    {
      id: 'deep-space-p4',
      pageNumber: 13,
      layout: 'both_generic',
      speaker: 'pioneer5' as const,
      speakerName: 'Pioneer 5 & Orbit',
      isConversation: true,
      leadQuote: "Hi! I'm Pioneer 5!",
      bodyComponent: (
        <span>
          Pioneer 5 flew in 1960. It circled the Sun between Earth and Venus. It studied the space between planets!
        </span>
      ),
      speechText: "Hi! I'm Pioneer 5! I orbit the Sun!",
      scienceFact: "Pioneer 5 (1960) sent radio signals from 36 million km away. That was a deep-space record!",
      interview: [["Orbit", "Pioneer 5, did you actually go to the Sun?"], ["Pioneer 5", "Not exactly! I traveled into an orbit around the Sun between Earth and Venus."], ["Orbit", "What were you studying?"], ["Pioneer 5", "The space between planets, especially the Sun's magnetic field and solar particles!"], ["Orbit", "Were you important for future missions?"], ["Pioneer 5", "Absolutely! I helped prove we could communicate with spacecraft across deep space."], ["Orbit", "Are you still sending messages?"], ["Pioneer 5", "Nope. My mission ended in 1960, but I'm still orbiting the Sun."]] as [string, string][],
      art: {"emoji": "☀️", "name": "Pioneer 5", "year": "1960"},
      orbitLine: "Pioneer 5, tell us about your trip!",
    },
    {
      pageNumber: 13,
      layout: 'both_generic',
      speaker: 'mariner2' as const,
      speakerName: 'Mariner 2 & Orbit',
      isConversation: true,
      leadQuote: "Hi! I'm Mariner 2!",
      bodyComponent: (
        <span>
          Mariner 2 was the first to fly past Venus. It had no cameras. Its instruments did the seeing!
        </span>
      ),
      speechText: "Hi! I'm Mariner 2! I flew past Venus first!",
      scienceFact: "Mariner 2 passed Venus on 14 December 1962. It found Venus is more than 400 degrees Celsius hot!",
      interview: [["Orbit", "Mariner 2, did you really reach Venus first?"], ["Mariner 2", "I did! 🟡 In 1962, I became the first spacecraft to successfully fly past Venus."], ["Orbit", "What did you discover?"], ["Mariner 2", "Venus is HOT! I measured its temperature, atmosphere and {{solar_wind|solar-wind}} environment."], ["Orbit", "Did you have cameras?"], ["Mariner 2", "Nope! My instruments did the seeing for me."], ["Orbit", "And now?"], ["Mariner 2", "I'm roaming around like a ghost."]] as [string, string][],
      art: {"emoji": "🟡", "name": "Mariner 2", "year": "1962"},
      orbitLine: "Mariner 2, what was Venus like?",
    },
    {
      pageNumber: 13,
      layout: 'both_generic',
      speaker: 'mariner10' as const,
      speakerName: 'Mariner 10 & Orbit',
      isConversation: true,
      leadQuote: "Hi! I'm Mariner 10!",
      bodyComponent: (
        <span>
          Mariner 10 visited Venus, then Mercury. It used Venus's gravity like a slingshot!
        </span>
      ),
      speechText: "Hi! I'm Mariner 10! I visited Venus and Mercury!",
      scienceFact: "Mariner 10 flew by Mercury 3 times in 1974 and 1975. It mapped about half of the planet!",
      interview: [["Orbit", "Mariner 10, where did you go first?"], ["Mariner 10", "Venus! Then I used its gravity to reach Mercury."], ["Orbit", "What did you find there?"], ["Mariner 10", "Craters, the huge Caloris Basin, extreme temperatures and a magnetic field!"], ["Orbit", "How many times did you visit Mercury?"], ["Mariner 10", "Three times! I photographed about half of its surface."], ["Orbit", "And now?"], ["Mariner 10", "My mission ended in 1975, but my discoveries opened the door to Mercury exploration!"]] as [string, string][],
      art: {"emoji": "🌑", "name": "Mariner 10", "year": "1973"},
      orbitLine: "Mariner 10, how did you reach Mercury?",
    },
    {
      pageNumber: 13,
      layout: 'both_pioneer', // BOTH Orbit and Pioneer 11 together!
      speaker: 'pioneer11' as const,
      speakerName: 'Pioneer 11 & Orbit',
      isConversation: true,
      leadQuote: "Hi! I'm Pioneer 11!",
      bodyComponent: (
        <span>
          Pioneer 11 flew past Jupiter. Then it visited Saturn! It was the first ever to do that.
        </span>
      ),
      speechText: "Hi! I'm Pioneer 11! I visited Saturn first!",
      scienceFact: "Pioneer 11 flew by Saturn on 1 September 1979. It passed just 21,000 km above the clouds!",
      interview: [["Orbit", "Pioneer 11, what was your big adventure?"], ["Pioneer 11", "I flew past Jupiter, then became the first spacecraft to visit Saturn!"], ["Orbit", "What did you see at Saturn?"], ["Pioneer 11", "Amazing rings, and I discovered Saturn's F ring and new moons!"], ["Orbit", "Did you study anything besides the rings?"], ["Pioneer 11", "Yes! I measured Saturn's magnetic environment and observed {{titan|Titan}}."], ["Orbit", "Are you still talking to Earth?"], ["Pioneer 11", "Nope! I'm asleep, drifting through space."]] as [string, string][],
    },
    {
      id: 'deep-space-p5',
      pageNumber: 14,
      layout: 'both_voyager', // BOTH Orbit and Voyager 1 together!
      speaker: 'voyager' as const,
      speakerName: 'Voyager 1 & Orbit',
      isConversation: true,
      leadQuote: "Hi! I'm Voyager 1! I'm far!",
      bodyComponent: (
        <span>
          In 2012, I crossed the <SpaceGlossaryWord termKey="heliopause" displayText="heliopause" />. Now I'm in <SpaceGlossaryWord termKey="interstellar" displayText="interstellar space" />! I carry the Golden Record.
        </span>
      ),
      speechText: "Hi! I'm Voyager 1! I crossed the heliopause! I carry the Golden Record!",
      scienceFact: "Voyager 1 is over 25 billion km away. It is the farthest human-made thing!",
      interview: [["Orbit", "Voyager, where are you?"], ["Voyager 1", "Between the stars! Wow!"], ["Orbit", "What did you see?"], ["Voyager 1", "Jupiter's volcanoes. Saturn's rings!"], ["Orbit", "What's on your record?"], ["Voyager 1", "Songs, greetings, whale sounds!"], ["Orbit", "Can you still talk?"], ["Voyager 1", "Yes! Radio takes 23 hours."]] as [string, string][],
    },
    {
      id: 'deep-space-p6',
      pageNumber: 15,
      layout: 'center',
      speaker: 'orbit' as const,
      speakerName: 'Orbit',
      isConversation: false,
      leadQuote: "Pioneer 10 whispered goodbye.",
      bodyComponent: (
        <span>
          On 23 January 2003, Pioneer 10 sent its last signal. It carried a plaque with Earth's map, drawn with <SpaceGlossaryWord termKey="pulsar" displayText="pulsars" />. It was planned for 21 months. It worked 30 years!
        </span>
      ),
      speechText: "Pioneer 10 whispered goodbye. It worked 30 years! Thank you, Pioneer!",
      scienceFact: "Pioneer 10's last signal came from 12 billion km away. Voyager 1 also saves power by turning off tools.",
      interview: [["Orbit", "Pioneer, are you tired?"], ["Pioneer 10", "My power is fading."], ["Orbit", "Don't be sad!"], ["Pioneer 10", "I'm not! I flew far."], ["Orbit", "Thank you, Pioneer!"]] as [string, string][],
    },
    {
            pageNumber: 16,
      layout: 'left', // Orbit on left, hope beat
      speaker: 'orbit' as const,
      speakerName: 'Orbit',
      isConversation: false,
      leadQuote: "They still travel! Hello, stars!",
      bodyComponent: (
        <span>
          Pioneer 10 is heading toward the star Aldebaran. That takes 2 million years. Voyager 1 will pass a star in about 40,000 years.
        </span>
      ),
      speechText: "They still travel! Maybe someone will find our hello!",
      scienceFact: "The Golden Record can last over a billion years!",
    },
  ], []);

  // FIX: Auto-voice on arrival when moving to this story
  useEffect(() => {
    playSceneMusic('deep_space');

    const arrivalVoiceTimer = window.setTimeout(() => {
      if (getSpeechEnabled()) {
        speakDialogue(beats[0].speaker, beats[0].speechText, { skipSoundCue: true });
      }
    }, 450);

    return () => window.clearTimeout(arrivalVoiceTimer);
  }, []);

  const handleSpeak = useCallback((beatIdx: number) => {
    const beat = beats[beatIdx];
    speakDialogue(beat.speaker, beat.speechText);
  }, [beats]);

  // Debounced scroll listener
  useEffect(() => {
    const handleScroll = () => {
      const beatElements = document.querySelectorAll('.deep-space-beat');
      if (beatElements.length === 0) return;

      const vCenter = window.innerHeight * 0.45;
      let closestIdx = 0;
      let minDistance = Infinity;

      beatElements.forEach((el, idx) => {
        const rect = el.getBoundingClientRect();
        const dist = Math.abs(rect.top + rect.height / 2 - vCenter);
        if (dist < minDistance) {
          minDistance = dist;
          closestIdx = idx;
        }
      });

      if (closestIdx !== activeBeat) {
        setActiveBeat(closestIdx);
        playPageTurn();
        const beat = beats[closestIdx];

        if (beat.speaker !== 'orbit') {
          playOrbitCue();
        }

        if (scrollTimeoutRef.current) window.clearTimeout(scrollTimeoutRef.current);
        scrollTimeoutRef.current = window.setTimeout(() => {
          if (getSpeechEnabled()) {
            speakDialogue(beat.speaker, beat.speechText, { skipSoundCue: true });
          }
        }, 220);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => {
      window.removeEventListener('scroll', handleScroll);
      if (scrollTimeoutRef.current) window.clearTimeout(scrollTimeoutRef.current);
    };
  }, [activeBeat, beats]);

  return (
    <section
      id="chosen-destination-story"
      className="relative w-full py-16 sm:py-24 text-amber-900 overflow-hidden bg-gradient-to-b from-[#fff1dc] via-[#ffe0b8] to-[#fff1dc]"
    >
      <div className="absolute inset-0 pointer-events-none opacity-40 z-0">
        <svg viewBox="0 0 1400 900" className="w-full h-full" preserveAspectRatio="none">
          <circle cx="280" cy="240" r="85" fill="#fde047" opacity="0.6" />
          <path d="M 195 220 Q 280 230 365 220" stroke="#ca8a04" strokeWidth="6" fill="none" opacity="0.7" />
          <path d="M 195 245 Q 280 255 365 245" stroke="#a16207" strokeWidth="5" fill="none" opacity="0.6" />
          <circle cx="310" cy="255" r="14" fill="#dc2626" opacity="0.75" />

          <circle cx="1120" cy="280" r="55" fill="#fcd34d" opacity="0.5" />
          <ellipse cx="1120" cy="280" rx="120" ry="24" stroke="#fde047" strokeWidth="6" fill="none" opacity="0.7" transform="rotate(-18 1120 280)" />

          <ellipse cx="700" cy="450" rx="600" ry="250" fill="#7e22ce" opacity="0.15" filter="blur(60px)" />
          <ellipse cx="850" cy="500" rx="450" ry="200" fill="#3b82f6" opacity="0.12" filter="blur(50px)" />

          <line x1="700" y1="450" x2="620" y2="350" stroke="#38bdf8" strokeWidth="1" strokeDasharray="4 4" opacity="0.3" />
          <line x1="700" y1="450" x2="820" y2="390" stroke="#38bdf8" strokeWidth="1" strokeDasharray="4 4" opacity="0.3" />
          <line x1="700" y1="450" x2="740" y2="560" stroke="#38bdf8" strokeWidth="1" strokeDasharray="4 4" opacity="0.3" />
        </svg>
      </div>

      <div className="relative z-10 w-full flex flex-col items-center">
        {/* Header with Larger Font */}
        <div className="pt-4 pb-12 px-4 text-center max-w-4xl mx-auto">
          
          <h2 className="text-3xl sm:text-5xl lg:text-6xl font-black text-amber-950 mt-3 tracking-tight drop-shadow-md">
            Solar System: Pioneer & Voyager
          </h2>
          
        </div>

        {/* Beats with Larger Fonts */}
        <div className="w-full flex flex-col items-center space-y-16 sm:space-y-24">
          {beats.map((beat, idx) => {
            const isActive = activeBeat === idx;
            const isCenter = beat.layout === 'center';
            const isBothGeneric = beat.layout === 'both_generic';
            const isBothPioneer = beat.layout === 'both_pioneer';
            const isBothVoyager = beat.layout === 'both_voyager';
            const isLeft = beat.layout === 'left';

            return (
              <div
                key={idx}
                id={beat.id}
                className={`deep-space-beat w-full min-h-[75vh] max-w-6xl px-4 sm:px-8 lg:px-12 flex items-center justify-center transition-all duration-500 ${
                  isActive ? 'opacity-100 scale-100' : 'opacity-65 scale-[0.98]'
                }`}
              >
               
                {isBothGeneric ? (
                  <div className="w-full flex flex-col items-center gap-6">
                    <div className="text-center max-w-3xl px-2">
                      <div className="text-lg sm:text-2xl text-purple-100 leading-relaxed font-bold">
                        {beat.bodyComponent}
                      </div>
                    </div>
                    <div className="w-full flex flex-row items-center justify-around gap-4 sm:gap-12 py-4">
                      <div className="flex flex-col items-center opacity-85 hover:opacity-100 transition-opacity">
                        <OrbitCharacter
                          mood="curious"
                          size="md"
                          onClick={() => speakDialogue('orbit', beat.orbitLine || 'Tell us your story!')}
                        />
                      </div>
                      <div className="text-purple-800 font-mono text-xs sm:text-sm opacity-75 animate-pulse">
                        <span>{beat.art?.emoji} ~ ~ ~ 🛰️</span>
                      </div>
                      <div className="flex flex-col items-center scale-105 filter drop-shadow-[0_0_20px_rgba(168,85,247,0.5)]">
                        <MissionIllustration
                          emoji={beat.art?.emoji || '🛰️'}
                          name={beat.art?.name || ''}
                          year={beat.art?.year || ''}
                          dark={true}
                          isSpeaking={isActive}
                          speechBubble={beat.leadQuote}
                          onClick={() => handleSpeak(idx)}
                        />
                      </div>
                    </div>
                    {beat.interview && <InterviewChat lines={beat.interview} dark={true} />}
                    <div className="p-4 sm:p-5 rounded-2xl bg-purple-950/70 backdrop-blur-md border border-purple-500/40 shadow-xl max-w-2xl text-center">
                      <p className="text-sm sm:text-base font-semibold text-purple-200 leading-snug">
                        🌌 <strong className="text-purple-100">NASA Discovery:</strong> {beat.scienceFact}
                      </p>
                    </div>
                  </div>
                ) : isBothPioneer ? (
                  <div className="w-full flex flex-col items-center gap-6">
                    <div className="text-center max-w-3xl px-2">
                      
                      <div className="text-lg sm:text-2xl text-amber-800/95 leading-relaxed font-bold">
                        {beat.bodyComponent}
                      </div>
                    </div>

                    <div className="w-full flex flex-row items-center justify-around gap-4 sm:gap-12 py-4">
                    
                      <div className="flex flex-col items-center opacity-85 hover:opacity-100 transition-opacity">
                        <OrbitCharacter
                          mood="curious"
                          size="md"
                          onClick={() => speakDialogue('orbit', "Pioneer 11, tell us about Saturn!")}
                        />
                       
                      </div>

                      <div className="text-purple-800 font-mono text-xs sm:text-sm opacity-75 animate-pulse">
                        <span>🪐 ~ ~ ~ 🛰️</span>
                      </div>

                      
                      <div className="flex flex-col items-center scale-105 filter drop-shadow-[0_0_20px_rgba(168,85,247,0.5)]">
                        <PioneerIllustration
                          isSpeaking={isActive}
                          speechBubble={beat.leadQuote}
                          onClick={() => handleSpeak(idx)}
                        />
                        
                      </div>
                    </div>

                    {beat.interview && <InterviewChat lines={beat.interview} dark={true} />}

                    <div className="p-4 sm:p-5 rounded-2xl bg-purple-950/70 backdrop-blur-md border border-purple-500/40 shadow-xl max-w-2xl text-center">
                      <p className="text-sm sm:text-base font-semibold text-purple-200 leading-snug">
                        🌌 <strong className="text-purple-100">NASA Discovery:</strong> {beat.scienceFact}
                      </p>
                    </div>
                  </div>
                ) : isBothVoyager ? (
                  
                  <div className="w-full flex flex-col items-center gap-6">
                    <div className="text-center max-w-3xl px-2">
                     
                      <div className="text-lg sm:text-2xl text-amber-800/95 leading-relaxed font-bold">
                        {beat.bodyComponent}
                      </div>
                    </div>

                    <div className="w-full flex flex-row items-center justify-around gap-4 sm:gap-12 py-4">
                     
                      <div className="flex flex-col items-center opacity-85 hover:opacity-100 transition-opacity">
                        <OrbitCharacter
                          mood="excited"
                          size="md"
                          onClick={() => speakDialogue('orbit', "Voyager, where are you now in the cosmos?")}
                        />
                       
                      </div>

                      <div className="text-purple-700 font-mono text-xs sm:text-sm opacity-75 animate-pulse">
                        <span>🌟 ~ ~ ~ 🛰️</span>
                      </div>

                      {/* Right: Voyager Speaking */}
                      <div className="flex flex-col items-center scale-105 filter drop-shadow-[0_0_20px_rgba(168,85,247,0.5)]">
                        <VoyagerIllustration
                          isSpeaking={isActive}
                          speechBubble={beat.leadQuote}
                          onClick={() => handleSpeak(idx)}
                        />
                        
                      </div>
                    </div>

                    {beat.interview && <InterviewChat lines={beat.interview} dark={true} />}

                    <div className="p-4 sm:p-5 rounded-2xl bg-purple-950/70 backdrop-blur-md border border-purple-500/40 shadow-xl max-w-2xl text-center">
                      <p className="text-sm sm:text-base font-semibold text-purple-200 leading-snug">
                        🌌 <strong className="text-purple-100">Interstellar Fact:</strong> {beat.scienceFact}
                      </p>
                    </div>
                  </div>
                ) : isCenter ? (
                  
                  <div className="w-full max-w-3xl flex flex-col items-center text-center gap-6">
                    <OrbitCharacter
                      mood="gentle"
                      size="lg"
                      isSpeaking={isActive}
                      speechBubble={beat.leadQuote}
                      onClick={() => handleSpeak(idx)}
                    />

                    <div>
                      
                      <div className="text-lg sm:text-2xl text-amber-800/95 leading-relaxed font-bold mb-4">
                        {beat.bodyComponent}
                      </div>

                      {beat.interview && <InterviewChat lines={beat.interview} dark={true} />}

                      <div className="p-4 sm:p-5 rounded-2xl bg-purple-950/70 backdrop-blur-md border border-purple-500/40 shadow-xl text-left inline-block">
                        <p className="text-sm sm:text-base font-semibold text-purple-200 leading-snug">
                          🌌 <strong className="text-purple-100">Cosmic Fact:</strong> {beat.scienceFact}
                        </p>
                      </div>
                    </div>
                  </div>
                ) : (
                  
                  <div className="w-full max-w-5xl flex gap-8 lg:gap-14 items-center flex-col lg:flex-row justify-between">
                    <div className="w-full lg:w-5/12 flex flex-col items-center justify-center">
                      <OrbitCharacter
                        mood="curious"
                        size="lg"
                        isSpeaking={isActive}
                        speechBubble={beat.leadQuote}
                        onClick={() => handleSpeak(idx)}
                      />
                     
                    </div>

                    <div className="w-full lg:w-7/12 flex flex-col justify-center max-w-xl">
                     

                      <div className="text-lg sm:text-2xl text-amber-800/95 leading-relaxed font-bold mb-4">
                        {beat.bodyComponent}
                      </div>

                      {beat.interview && <InterviewChat lines={beat.interview} dark={true} />}

                      <div className="p-4 sm:p-5 rounded-2xl bg-purple-950/70 backdrop-blur-md border border-purple-500/40 shadow-xl">
                        <p className="text-sm sm:text-base font-semibold text-purple-200 leading-snug">
                          🌌 <strong className="text-purple-100">NASA Discovery:</strong> {beat.scienceFact}
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default Page6DeepSpacePath;